pytest tests --cov-report html --cov=autokeras
