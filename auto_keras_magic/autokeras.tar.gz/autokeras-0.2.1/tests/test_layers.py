# TODO: test produce output shape

